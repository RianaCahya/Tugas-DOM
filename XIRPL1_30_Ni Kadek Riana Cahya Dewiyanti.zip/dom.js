document.addEventListener('DOMContentLoaded', () => {
    const toggleButton = document.getElementById('toggleImage');
    const image = document.getElementById('gambar');

    const images = ['bunga1.jpeg', 'bunga2.jpeg', 'bunga3.jpeg'];
    let currentIndex = 0;

    toggleButton.addEventListener('click', () => {
        currentIndex = (currentIndex + 1) % images.length;
        image.src = images[currentIndex];
    });
});